package ir.webline.customers.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "message_templates")
data class MessageTemplate(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val key: String, // unique lookup key e.g. "payment_reminder"
    val title: String, // UI title
    val templateContent: String // template with placeholders
)
