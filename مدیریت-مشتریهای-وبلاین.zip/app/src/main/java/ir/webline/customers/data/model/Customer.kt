package ir.webline.customers.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "customers")
data class Customer(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val brandName: String = "",
    val phoneNumber: String = "",
    val email: String = "",
    val projectName: String = "",
    val projectDescription: String = "",
    val status: String = "", // e.g. طراحی سایت, سئو, etc.
    val paymentStatus: String = "", // e.g. پرداخت شده, پرداخت نشده, etc.
    val amount: Double = 0.0,
    val shebaNumber: String = "",
    val startDate: String = "", // e.g. "1402/01/01"
    val nextRenewalDate: String = "", // e.g. "1402/02/01"
    val notes: String = "", // General customer notes
    val tags: String = "" // Comma-separated tags
)
