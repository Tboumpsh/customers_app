package ir.webline.customers.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tasks")
data class Task(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val customerId: Int,
    val title: String,
    val description: String = "",
    val dueDate: String = "", // e.g. "1402/01/15"
    val status: String = "انجام نشده", // انجام نشده، در حال انجام، انجام شده
    val priority: String = "متوسط" // کم، متوسط، زیاد
)
