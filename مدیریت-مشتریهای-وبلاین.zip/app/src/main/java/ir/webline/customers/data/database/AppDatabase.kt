package ir.webline.customers.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import ir.webline.customers.data.model.Customer
import ir.webline.customers.data.model.CustomerNote
import ir.webline.customers.data.model.MessageTemplate
import ir.webline.customers.data.model.Task

@Database(
    entities = [
        Customer::class,
        Task::class,
        CustomerNote::class,
        MessageTemplate::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun customerDao(): CustomerDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "webline_customers_db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
