package ir.webline.customers.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.webline.customers.data.model.Customer
import ir.webline.customers.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerListScreen(
    customers: List<Customer>,
    searchQuery: String,
    filterStatus: String,
    filterPayment: String,
    onSearchChange: (String) -> Unit,
    onFilterStatusChange: (String) -> Unit,
    onFilterPaymentChange: (String) -> Unit,
    onNavigateToAddCustomer: () -> Unit,
    onNavigateToCustomerDetail: (Int) -> Unit
) {
    var showFilterSection by remember { mutableStateOf(false) }

    val statusOptions = listOf(
        "" to "همه استاتوس‌ها",
        "طراحی سایت" to "طراحی سایت",
        "سئو" to "سئو",
        "پشتیبانی فنی" to "پشتیبانی فنی",
        "پلن رشد" to "پلن رشد",
        "پرداخت نشده" to "پرداخت نشده",
        "در انتظار تایید" to "در انتظار تایید",
        "ادمین محتوایی" to "ادمین محتوایی"
    )

    val paymentOptions = listOf(
        "" to "همه وضعیت‌های پرداخت",
        "پرداخت شده" to "پرداخت شده",
        "پرداخت نشده" to "پرداخت نشده",
        "پرداخت ناقص" to "پرداخت ناقص",
        "در انتظار بررسی" to "در انتظار بررسی"
    )

    Scaffold(
        containerColor = LightGraySurface,
        floatingActionButton = {
            FloatingActionButton(
                onClick = onNavigateToAddCustomer,
                containerColor = NavyPrimary,
                contentColor = Color.White,
                shape = CircleShape,
                modifier = Modifier.testTag("add_customer_fab")
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "افزودن مشتری")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            // Header Title
            Text(
                text = "دفترچه مشتریان وبلاین",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = NavyPrimary,
                modifier = Modifier.padding(vertical = 16.dp)
            )

            // Search Bar & Filter Toggle Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchChange,
                    placeholder = { Text("جستجوی مشتری یا پروژه...", fontSize = 13.sp) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "جستجو",
                            tint = TextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    },
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        focusedIndicatorColor = NavyPrimary,
                        unfocusedIndicatorColor = BorderColor
                    ),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp)
                        .testTag("customer_search_input")
                        .border(1.dp, BorderColor, RoundedCornerShape(16.dp)),
                    singleLine = true
                )

                IconButton(
                    onClick = { showFilterSection = !showFilterSection },
                    modifier = Modifier
                        .background(
                            if (showFilterSection || filterStatus.isNotEmpty() || filterPayment.isNotEmpty())
                                NavyPrimary.copy(alpha = 0.1f)
                            else Color.White,
                            RoundedCornerShape(16.dp)
                        )
                        .size(52.dp)
                        .border(1.dp, BorderColor, RoundedCornerShape(16.dp))
                        .testTag("customer_filter_toggle_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.FilterList,
                        contentDescription = "فیلترها",
                        tint = if (showFilterSection || filterStatus.isNotEmpty() || filterPayment.isNotEmpty())
                            NavyPrimary else TextSecondary
                    )
                }
            }

            // Expanding Filters Panel
            AnimatedVisibility(visible = showFilterSection) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                        .border(1.dp, BorderColor, RoundedCornerShape(20.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "فیلتر بر اساس نوع خدمات (استاتوس):",
                            fontSize = 12.sp,
                            color = TextSecondary,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )

                        // Scrollable status filter options
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp)
                        ) {
                            val activeStatusValue = filterStatus
                            statusOptions.take(4).forEach { option ->
                                val selected = option.first == activeStatusValue
                                FilterChip(
                                    selected = selected,
                                    onClick = { onFilterStatusChange(option.first) },
                                    label = { Text(option.second, fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = NavyPrimary,
                                        selectedLabelColor = Color.White
                                    )
                                )
                            }
                        }

                        Text(
                            text = "وضعیت پرداخت:",
                            fontSize = 12.sp,
                            color = TextSecondary,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            paymentOptions.take(3).forEach { option ->
                                val selected = option.first == filterPayment
                                FilterChip(
                                    selected = selected,
                                    onClick = { onFilterPaymentChange(option.first) },
                                    label = { Text(option.second, fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = NavyPrimary,
                                        selectedLabelColor = Color.White
                                    )
                                )
                            }
                        }
                    }
                }
            }

            // Customers List
            if (customers.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "مشتری یافت نشد",
                            color = TextSecondary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "لطفاً عبارت دیگری را جستجو کنید یا فیلترها را بردارید.",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(bottom = 80.dp),
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f)
                ) {
                    items(customers) { customer ->
                        CustomerItemCard(customer = customer) {
                            onNavigateToCustomerDetail(customer.id)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CustomerItemCard(customer: Customer, onClick: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .border(1.dp, BorderColor, RoundedCornerShape(20.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Row 1: Name and Project Name
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = customer.name,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = TextPrimary
                    )
                    Text(
                        text = "برند: ${customer.brandName.ifEmpty { "ثبت نشده" }}",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                }

                // Project Status Badge
                Box(
                    modifier = Modifier
                        .background(NavyPrimary.copy(alpha = 0.1f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = customer.status.ifEmpty { "نامشخص" },
                        color = NavyPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Row 2: Financial Details and Status
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "پروژه: ${customer.projectName}",
                        fontSize = 12.sp,
                        color = TextPrimary,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "مبلغ: ${"%,.0f".format(customer.amount)} ریال",
                        fontSize = 12.sp,
                        color = TextPrimary
                    )
                }

                // Payment Status Badge
                val paymentColor = when (customer.paymentStatus) {
                    "پرداخت شده" -> StatusGreen
                    "پرداخت نشده" -> StatusRed
                    "پرداخت ناقص" -> StatusYellow
                    else -> TextSecondary
                }

                Box(
                    modifier = Modifier
                        .background(paymentColor.copy(alpha = 0.1f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = customer.paymentStatus.ifEmpty { "بدون وضعیت" },
                        color = paymentColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            if (customer.nextRenewalDate.isNotEmpty()) {
                Spacer(modifier = Modifier.height(10.dp))
                Divider(color = BorderColor.copy(alpha = 0.5f))
                Spacer(modifier = Modifier.height(8.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "تمدید بعدی: ${customer.nextRenewalDate}",
                        fontSize = 11.sp,
                        color = TextSecondary,
                        fontWeight = FontWeight.Medium
                    )

                    if (customer.notes.isNotEmpty()) {
                        Text(
                            text = customer.notes,
                            fontSize = 11.sp,
                            color = TextSecondary,
                            maxLines = 1,
                            modifier = Modifier.weight(1f, fill = false).padding(start = 16.dp)
                        )
                    }
                }
            }
        }
    }
}
