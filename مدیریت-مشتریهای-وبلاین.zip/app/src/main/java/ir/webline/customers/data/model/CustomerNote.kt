package ir.webline.customers.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "customer_notes")
data class CustomerNote(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val customerId: Int,
    val date: String, // e.g. "1402/01/10"
    val title: String,
    val description: String = "",
    val importanceLevel: String = "متوسط" // کم، متوسط، زیاد، بسیار مهم
)
