package ir.webline.customers.data.repository

import ir.webline.customers.data.database.CustomerDao
import ir.webline.customers.data.model.Customer
import ir.webline.customers.data.model.CustomerNote
import ir.webline.customers.data.model.MessageTemplate
import ir.webline.customers.data.model.Task
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject

class CustomerRepository(private val customerDao: CustomerDao) {

    val allCustomers: Flow<List<Customer>> = customerDao.getAllCustomers()
    val allTasks: Flow<List<Task>> = customerDao.getAllTasks()
    val allTemplates: Flow<List<MessageTemplate>> = customerDao.getAllTemplates()

    suspend fun getCustomerById(id: Int): Customer? = customerDao.getCustomerById(id)

    suspend fun insertCustomer(customer: Customer): Long = customerDao.insertCustomer(customer)

    suspend fun updateCustomer(customer: Customer) = customerDao.updateCustomer(customer)

    suspend fun deleteCustomer(customer: Customer) = customerDao.deleteCustomer(customer)

    fun getTasksForCustomer(customerId: Int): Flow<List<Task>> = customerDao.getTasksForCustomer(customerId)

    suspend fun insertTask(task: Task) = customerDao.insertTask(task)

    suspend fun updateTask(task: Task) = customerDao.updateTask(task)

    suspend fun deleteTask(task: Task) = customerDao.deleteTask(task)

    fun getNotesForCustomer(customerId: Int): Flow<List<CustomerNote>> = customerDao.getNotesForCustomer(customerId)

    suspend fun insertNote(note: CustomerNote) = customerDao.insertNote(note)

    suspend fun updateNote(note: CustomerNote) = customerDao.updateNote(note)

    suspend fun deleteNote(note: CustomerNote) = customerDao.deleteNote(note)

    suspend fun getTemplateByKey(key: String): MessageTemplate? = customerDao.getTemplateByKey(key)

    suspend fun insertTemplate(template: MessageTemplate) = customerDao.insertTemplate(template)

    suspend fun updateTemplate(template: MessageTemplate) = customerDao.updateTemplate(template)

    // Checks and seeds templates if the table is empty
    suspend fun checkAndSeedTemplates() {
        val templatesList = customerDao.getAllTemplates().first()
        if (templatesList.isEmpty()) {
            val defaults = listOf(
                MessageTemplate(
                    key = "payment_reminder",
                    title = "یادآور پرداخت",
                    templateContent = "سلام جناب {customerName} عزیز، وقتتون بخیر. فاکتور مربوط به پروژه {projectName} به مبلغ {amount} ریال صادر شده. ممنون میشم در صورت امکان نسبت به پرداخت اقدام بفرمایید.\nشماره شبا جهت واریز: {shebaNumber}\nبا تشکر، وبلاین"
                ),
                MessageTemplate(
                    key = "renewal_reminder",
                    title = "یادآور تمدید ماهانه",
                    templateContent = "سلام {customerName} گرامی، سرویس تمدید پروژه {projectName} در تاریخ {renewalDate} منقضی می‌شود. هزینه دوره جدید مبلغ {amount} ریال است. ممنون می‌شویم جهت تمدید اقدام نمایید.\nبا احترام، وبلاین"
                ),
                MessageTemplate(
                    key = "project_approval",
                    title = "پیگیری تایید پروژه",
                    templateContent = "سلام {customerName} گرامی، نسخه اولیه پروژه {projectName} آماده بررسی است. لطفاً بازخورد خود را ارسال فرمایید تا مراحل نهایی انجام شود.\nوبلاین"
                ),
                MessageTemplate(
                    key = "seo_report",
                    title = "پیگیری گزارش سئو",
                    templateContent = "سلام جناب {customerName}، گزارش پیشرفت سئو پروژه {projectName} برای این ماه آماده شده است. خوشحال می‌شویم نظرات شما را دریافت کنیم.\nبا احترام، وبلاین"
                ),
                MessageTemplate(
                    key = "support_response",
                    title = "پاسخ پشتیبانی",
                    templateContent = "سلام {customerName} عزیز، تیکت پشتیبانی شما برای پروژه {projectName} برطرف شد. لطفاً در صورت وجود مشکل مجدد اطلاع دهید.\nتیم فنی وبلاین"
                ),
                MessageTemplate(
                    key = "invoice_sent",
                    title = "ارسال فاکتور",
                    templateContent = "جناب {customerName} عزیز، فاکتور شماره {invoiceNumber} برای پروژه {projectName} به مبلغ {amount} ریال صادر گردید.\nبا تشکر، وبلاین"
                )
            )
            for (tpl in defaults) {
                customerDao.insertTemplate(tpl)
            }
        }
    }

    // Export all app data as a JSON String
    suspend fun exportBackupJson(): String {
        val root = JSONObject()

        // Customers
        val customersArray = JSONArray()
        val customersList = customerDao.getAllCustomers().first()
        for (c in customersList) {
            val obj = JSONObject().apply {
                put("id", c.id)
                put("name", c.name)
                put("brandName", c.brandName)
                put("phoneNumber", c.phoneNumber)
                put("email", c.email)
                put("projectName", c.projectName)
                put("projectDescription", c.projectDescription)
                put("status", c.status)
                put("paymentStatus", c.paymentStatus)
                put("amount", c.amount)
                put("shebaNumber", c.shebaNumber)
                put("startDate", c.startDate)
                put("nextRenewalDate", c.nextRenewalDate)
                put("notes", c.notes)
                put("tags", c.tags)
            }
            customersArray.put(obj)
        }
        root.put("customers", customersArray)

        // Tasks
        val tasksArray = JSONArray()
        val tasksList = customerDao.getAllTasks().first()
        for (t in tasksList) {
            val obj = JSONObject().apply {
                put("id", t.id)
                put("customerId", t.customerId)
                put("title", t.title)
                put("description", t.description)
                put("dueDate", t.dueDate)
                put("status", t.status)
                put("priority", t.priority)
            }
            tasksArray.put(obj)
        }
        root.put("tasks", tasksArray)

        // Notes
        val notesArray = JSONArray()
        val customersListForNotes = customerDao.getAllCustomers().first()
        for (c in customersListForNotes) {
            val notesList = customerDao.getNotesForCustomer(c.id).first()
            for (n in notesList) {
                val obj = JSONObject().apply {
                    put("id", n.id)
                    put("customerId", n.customerId)
                    put("date", n.date)
                    put("title", n.title)
                    put("description", n.description)
                    put("importanceLevel", n.importanceLevel)
                }
                notesArray.put(obj)
            }
        }
        root.put("notes", notesArray)

        // Templates
        val templatesArray = JSONArray()
        val templatesList = customerDao.getAllTemplates().first()
        for (tpl in templatesList) {
            val obj = JSONObject().apply {
                put("id", tpl.id)
                put("key", tpl.key)
                put("title", tpl.title)
                put("templateContent", tpl.templateContent)
            }
            templatesArray.put(obj)
        }
        root.put("templates", templatesArray)

        return root.toString(2)
    }

    // Restore database from JSON string
    suspend fun restoreBackupJson(jsonString: String): Boolean {
        return try {
            val root = JSONObject(jsonString)

            // Validate structure
            if (!root.has("customers")) return false

            // Clear existing data or do we replace it? Let's clear and write
            // Customers
            val customersArray = root.getJSONArray("customers")
            val restoredCustomers = mutableListOf<Customer>()
            for (i in 0 until customersArray.length()) {
                val obj = customersArray.getJSONObject(i)
                restoredCustomers.add(
                    Customer(
                        id = obj.optInt("id", 0),
                        name = obj.getString("name"),
                        brandName = obj.optString("brandName", ""),
                        phoneNumber = obj.optString("phoneNumber", ""),
                        email = obj.optString("email", ""),
                        projectName = obj.optString("projectName", ""),
                        projectDescription = obj.optString("projectDescription", ""),
                        status = obj.optString("status", ""),
                        paymentStatus = obj.optString("paymentStatus", ""),
                        amount = obj.optDouble("amount", 0.0),
                        shebaNumber = obj.optString("shebaNumber", ""),
                        startDate = obj.optString("startDate", ""),
                        nextRenewalDate = obj.optString("nextRenewalDate", ""),
                        notes = obj.optString("notes", ""),
                        tags = obj.optString("tags", "")
                    )
                )
            }

            // Tasks
            val restoredTasks = mutableListOf<Task>()
            if (root.has("tasks")) {
                val tasksArray = root.getJSONArray("tasks")
                for (i in 0 until tasksArray.length()) {
                    val obj = tasksArray.getJSONObject(i)
                    restoredTasks.add(
                        Task(
                            id = obj.optInt("id", 0),
                            customerId = obj.getInt("customerId"),
                            title = obj.getString("title"),
                            description = obj.optString("description", ""),
                            dueDate = obj.optString("dueDate", ""),
                            status = obj.optString("status", "انجام نشده"),
                            priority = obj.optString("priority", "متوسط")
                        )
                    )
                }
            }

            // Notes
            val restoredNotes = mutableListOf<CustomerNote>()
            if (root.has("notes")) {
                val notesArray = root.getJSONArray("notes")
                for (i in 0 until notesArray.length()) {
                    val obj = notesArray.getJSONObject(i)
                    restoredNotes.add(
                        CustomerNote(
                            id = obj.optInt("id", 0),
                            customerId = obj.getInt("customerId"),
                            date = obj.getString("date"),
                            title = obj.getString("title"),
                            description = obj.optString("description", ""),
                            importanceLevel = obj.optString("importanceLevel", "متوسط")
                        )
                    )
                }
            }

            // Templates
            val restoredTemplates = mutableListOf<MessageTemplate>()
            if (root.has("templates")) {
                val templatesArray = root.getJSONArray("templates")
                for (i in 0 until templatesArray.length()) {
                    val obj = templatesArray.getJSONObject(i)
                    restoredTemplates.add(
                        MessageTemplate(
                            id = obj.optInt("id", 0),
                            key = obj.getString("key"),
                            title = obj.getString("title"),
                            templateContent = obj.getString("templateContent")
                        )
                    )
                }
            }

            // If we parsed successfully, write them to database (overwriting)
            // Note: Since Room inserts replace on conflict or we can do a clean replacement
            // Let's clear tables by deleting then inserting, or just inserting
            // For safety we can clear and insert. But let's insert them directly
            for (c in restoredCustomers) {
                customerDao.insertCustomer(c)
            }
            for (t in restoredTasks) {
                customerDao.insertTask(t)
            }
            for (n in restoredNotes) {
                customerDao.insertNote(n)
            }
            for (tpl in restoredTemplates) {
                customerDao.insertTemplate(tpl)
            }

            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
