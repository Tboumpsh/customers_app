package ir.webline.customers

import android.app.Application
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import ir.webline.customers.data.model.Customer
import ir.webline.customers.data.model.CustomerNote
import ir.webline.customers.data.model.Task
import ir.webline.customers.ui.screens.*
import ir.webline.customers.ui.theme.WeblineCustomersTheme
import ir.webline.customers.util.PdfGenerator
import ir.webline.customers.viewmodel.CustomerViewModel
import ir.webline.customers.viewmodel.CustomerViewModelFactory
import kotlinx.coroutines.launch
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

class MainActivity : ComponentActivity() {

    private val viewModel: CustomerViewModel by viewModels {
        CustomerViewModelFactory(application)
    }

    // Temporary variables for PDF invoice printing metadata
    private var pendingPdfCustomer: Customer? = null
    private var pendingInvoiceNo: String = "1001"
    private var pendingInvoiceDesc: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Create PDF document launcher using Storage Access Framework
        val createPdfLauncher = registerForActivityResult(
            ActivityResultContracts.CreateDocument("application/pdf")
        ) { uri ->
            if (uri != null && pendingPdfCustomer != null) {
                try {
                    contentResolver.openOutputStream(uri)?.use { outputStream ->
                        PdfGenerator.generateInvoicePdf(
                            customer = pendingPdfCustomer!!,
                            invoiceNumber = pendingInvoiceNo,
                            dateString = "1405/04/13", // Static Persian date or dynamic helper
                            description = pendingInvoiceDesc,
                            outputStream = outputStream
                        )
                        Toast.makeText(this, "فاکتور PDF با موفقیت ذخیره شد", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                    Toast.makeText(this, "خطا در ساخت فاکتور PDF", Toast.LENGTH_LONG).show()
                }
            }
        }

        setContent {
            WeblineCustomersTheme {
                val isLocked by viewModel.isLocked.collectAsStateWithLifecycle()
                val isPinEnabled by viewModel.isPinEnabled.collectAsStateWithLifecycle()

                // Force Right-to-Left (RTL) globally for perfect Persian UX!
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    if (isLocked) {
                        PinLockScreen(
                            isPinEnabled = isPinEnabled,
                            onVerifyPin = { pin -> viewModel.verifyPin(pin) },
                            onSavePin = { pin -> viewModel.savePin(pin) }
                        )
                    } else {
                        val navController = rememberNavController()
                        val coroutineScope = rememberCoroutineScope()

                        val customers by viewModel.filteredCustomers.collectAsStateWithLifecycle()
                        val rawCustomers by viewModel.allCustomers.collectAsStateWithLifecycle()
                        val recentCustomers by viewModel.recentCustomers.collectAsStateWithLifecycle()
                        val renewalsDueSoon by viewModel.renewalsDueSoon.collectAsStateWithLifecycle()
                        val urgentTasks by viewModel.urgentTasks.collectAsStateWithLifecycle()
                        val templates by viewModel.allTemplates.collectAsStateWithLifecycle()

                        // Search parameters
                        val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
                        val filterStatus by viewModel.filterStatus.collectAsStateWithLifecycle()
                        val filterPaymentStatus by viewModel.filterPaymentStatus.collectAsStateWithLifecycle()

                        Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                            NavHost(
                                navController = navController,
                                startDestination = "dashboard",
                                modifier = Modifier.padding(innerPadding)
                            ) {
                                // 1. Dashboard Page
                                composable("dashboard") {
                                    DashboardScreen(
                                        customers = rawCustomers,
                                        recentCustomers = recentCustomers,
                                        renewalsDue = renewalsDueSoon,
                                        urgentTasks = urgentTasks,
                                        onNavigateToCustomerList = { navController.navigate("customer_list") },
                                        onNavigateToCustomerDetail = { id -> navController.navigate("customer_detail/$id") },
                                        onNavigateToSettings = { navController.navigate("settings") }
                                    )
                                }

                                // 2. Customer List Directory Page
                                composable("customer_list") {
                                    CustomerListScreen(
                                        customers = customers,
                                        searchQuery = searchQuery,
                                        filterStatus = filterStatus,
                                        filterPayment = filterPaymentStatus,
                                        onSearchChange = { viewModel.searchQuery.value = it },
                                        onFilterStatusChange = { viewModel.filterStatus.value = it },
                                        onFilterPaymentChange = { viewModel.filterPaymentStatus.value = it },
                                        onNavigateToAddCustomer = { navController.navigate("customer_add") },
                                        onNavigateToCustomerDetail = { id -> navController.navigate("customer_detail/$id") }
                                    )
                                }

                                // 3. Customer Register/Add Page
                                composable("customer_add") {
                                    CustomerAddEditScreen(
                                        customerToEdit = null,
                                        onSaveCustomer = { c ->
                                            viewModel.addCustomer(c) { newId ->
                                                navController.popBackStack()
                                                navController.navigate("customer_detail/$newId")
                                            }
                                        },
                                        onNavigateBack = { navController.popBackStack() }
                                    )
                                }

                                // 4. Customer Edit Page
                                composable(
                                    "customer_edit/{customerId}",
                                    arguments = listOf(navArgument("customerId") { type = NavType.IntType })
                                ) { backStackEntry ->
                                    val customerId = backStackEntry.arguments?.getInt("customerId") ?: 0
                                    val customer = rawCustomers.find { it.id == customerId }
                                    
                                    CustomerAddEditScreen(
                                        customerToEdit = customer,
                                        onSaveCustomer = { updated ->
                                            viewModel.updateCustomer(updated)
                                            navController.popBackStack()
                                        },
                                        onNavigateBack = { navController.popBackStack() }
                                    )
                                }

                                // 5. Customer Profile Details Page
                                composable(
                                    "customer_detail/{customerId}",
                                    arguments = listOf(navArgument("customerId") { type = NavType.IntType })
                                ) { backStackEntry ->
                                    val customerId = backStackEntry.arguments?.getInt("customerId") ?: 0
                                    val customer = rawCustomers.find { it.id == customerId }

                                    if (customer != null) {
                                        val tasks by viewModel.getTasksForCustomer(customerId)
                                            .collectAsState(initial = emptyList())
                                        val notes by viewModel.getNotesForCustomer(customerId)
                                            .collectAsState(initial = emptyList())

                                        CustomerDetailScreen(
                                            customer = customer,
                                            tasks = tasks,
                                            notes = notes,
                                            templates = templates,
                                            onEditCustomer = { navController.navigate("customer_edit/$customerId") },
                                            onDeleteCustomer = {
                                                viewModel.deleteCustomer(customer)
                                                navController.popBackStack()
                                            },
                                            onAddTask = { viewModel.addTask(it) },
                                            onDeleteTask = { viewModel.deleteTask(it) },
                                            onToggleTaskStatus = { task ->
                                                val nextStatus = if (task.status == "انجام شده") "انجام نشده" else "انجام شده"
                                                viewModel.updateTask(task.copy(status = nextStatus))
                                            },
                                            onAddNote = { viewModel.addNote(it) },
                                            onDeleteNote = { viewModel.deleteNote(it) },
                                            onGeneratePdf = { invoiceNo, invoiceDesc ->
                                                pendingPdfCustomer = customer
                                                pendingInvoiceNo = invoiceNo
                                                pendingInvoiceDesc = invoiceDesc
                                                createPdfLauncher.launch("invoice_${customer.id}_$invoiceNo.pdf")
                                            },
                                            onNavigateBack = { navController.popBackStack() }
                                        )
                                    }
                                }

                                // 6. Application Settings Page
                                composable("settings") {
                                    SettingsScreen(
                                        isPinEnabled = isPinEnabled,
                                        onSaveNewPin = { pin -> viewModel.savePin(pin) },
                                        onDisablePin = { viewModel.disablePin() },
                                        onExportBackup = { uri ->
                                            coroutineScope.launch {
                                                try {
                                                    contentResolver.openOutputStream(uri)?.use { outputStream ->
                                                        val backupText = viewModel.exportBackupJson()
                                                        outputStream.write(backupText.toByteArray())
                                                        Toast.makeText(this@MainActivity, "پشتیبان‌گیری با موفقیت انجام شد", Toast.LENGTH_SHORT).show()
                                                    }
                                                } catch (e: Exception) {
                                                    e.printStackTrace()
                                                    Toast.makeText(this@MainActivity, "خطا در پشتیبان‌گیری", Toast.LENGTH_SHORT).show()
                                                }
                                            }
                                        },
                                        onRestoreBackup = { uri ->
                                            coroutineScope.launch {
                                                try {
                                                    contentResolver.openInputStream(uri)?.use { inputStream ->
                                                        val json = inputStream.bufferedReader().use { it.readText() }
                                                        val success = viewModel.restoreBackupJson(json)
                                                        if (success) {
                                                            Toast.makeText(this@MainActivity, "بازیابی اطلاعات با موفقیت انجام شد", Toast.LENGTH_LONG).show()
                                                        } else {
                                                            Toast.makeText(this@MainActivity, "خطا: فایل پشتیبان نامعتبر است", Toast.LENGTH_LONG).show()
                                                        }
                                                    }
                                                } catch (e: Exception) {
                                                    e.printStackTrace()
                                                    Toast.makeText(this@MainActivity, "خطا در بازیابی اطلاعات", Toast.LENGTH_LONG).show()
                                                }
                                            }
                                        },
                                        onNavigateBack = { navController.popBackStack() }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        viewModel.checkAutoLockOnResume()
    }

    override fun onStop() {
        super.onStop()
        viewModel.setBackgroundedTime()
    }
}
