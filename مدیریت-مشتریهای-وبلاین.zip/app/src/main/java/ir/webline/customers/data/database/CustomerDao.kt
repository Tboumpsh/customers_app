package ir.webline.customers.data.database

import androidx.room.*
import ir.webline.customers.data.model.Customer
import ir.webline.customers.data.model.CustomerNote
import ir.webline.customers.data.model.MessageTemplate
import ir.webline.customers.data.model.Task
import kotlinx.coroutines.flow.Flow

@Dao
interface CustomerDao {

    // Customer operations
    @Query("SELECT * FROM customers ORDER BY id DESC")
    fun getAllCustomers(): Flow<List<Customer>>

    @Query("SELECT * FROM customers WHERE id = :id")
    suspend fun getCustomerById(id: Int): Customer?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomer(customer: Customer): Long

    @Update
    suspend fun updateCustomer(customer: Customer)

    @Delete
    suspend fun deleteCustomer(customer: Customer)

    // Task operations
    @Query("SELECT * FROM tasks WHERE customerId = :customerId ORDER BY id DESC")
    fun getTasksForCustomer(customerId: Int): Flow<List<Task>>

    @Query("SELECT * FROM tasks ORDER BY id DESC")
    fun getAllTasks(): Flow<List<Task>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: Task)

    @Update
    suspend fun updateTask(task: Task)

    @Delete
    suspend fun deleteTask(task: Task)

    // Note operations
    @Query("SELECT * FROM customer_notes WHERE customerId = :customerId ORDER BY id DESC")
    fun getNotesForCustomer(customerId: Int): Flow<List<CustomerNote>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: CustomerNote)

    @Update
    suspend fun updateNote(note: CustomerNote)

    @Delete
    suspend fun deleteNote(note: CustomerNote)

    // Message Template operations
    @Query("SELECT * FROM message_templates ORDER BY id ASC")
    fun getAllTemplates(): Flow<List<MessageTemplate>>

    @Query("SELECT * FROM message_templates WHERE `key` = :key LIMIT 1")
    suspend fun getTemplateByKey(key: String): MessageTemplate?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTemplate(template: MessageTemplate)

    @Update
    suspend fun updateTemplate(template: MessageTemplate)
}
