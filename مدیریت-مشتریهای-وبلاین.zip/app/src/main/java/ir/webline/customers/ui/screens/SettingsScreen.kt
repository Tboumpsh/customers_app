package ir.webline.customers.ui.screens

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.webline.customers.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    isPinEnabled: Boolean,
    onSaveNewPin: (String) -> Unit,
    onDisablePin: () -> Unit,
    onExportBackup: (android.net.Uri) -> Unit,
    onRestoreBackup: (android.net.Uri) -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    // PIN change states
    var pinInputValue by remember { mutableStateOf("") }
    var pinEnableSwitchChecked by remember { mutableStateOf(isPinEnabled) }

    // Backup launchers
    val exportJsonLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            onExportBackup(uri)
        }
    }

    val importJsonLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            onRestoreBackup(uri)
        }
    }

    Scaffold(
        containerColor = LightGraySurface,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "تنظیمات برنامه وبلاین",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = NavyPrimary
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "بازگشت",
                            tint = NavyPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Section 1: Security PIN Settings
            SettingsSectionCard(title = "امنیت و قفل برنامه", icon = Icons.Default.Security) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "فعال‌سازی رمز عبور هنگام ورود",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "با خاموش کردن این گزینه، ورود بدون پین‌کد انجام می‌شود.",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                    Switch(
                        checked = pinEnableSwitchChecked,
                        onCheckedChange = { checked ->
                            pinEnableSwitchChecked = checked
                            if (!checked) {
                                onDisablePin()
                                Toast.makeText(context, "قفل امنیتی غیرفعال شد", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = SwitchDefaults.colors(checkedTrackColor = NavyPrimary),
                        modifier = Modifier.testTag("pin_lock_switch")
                    )
                }

                if (pinEnableSwitchChecked) {
                    Divider(color = BorderColor.copy(alpha = 0.5f), modifier = Modifier.padding(vertical = 12.dp))
                    
                    Text(
                        text = "تغییر یا تنظیم پین‌کد جدید (۴ رقم)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = NavyPrimary
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = pinInputValue,
                            onValueChange = { if (it.length <= 4) pinInputValue = it },
                            placeholder = { Text("مثال: 1234", fontSize = 12.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.White,
                                unfocusedContainerColor = Color.White,
                                focusedIndicatorColor = NavyPrimary,
                                unfocusedIndicatorColor = BorderColor
                            ),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(52.dp)
                                .border(1.dp, BorderColor, RoundedCornerShape(16.dp))
                                .testTag("pin_change_input"),
                            singleLine = true
                        )

                        Button(
                            onClick = {
                                if (pinInputValue.length == 4) {
                                    onSaveNewPin(pinInputValue)
                                    pinInputValue = ""
                                    Toast.makeText(context, "پین‌کد جدید ذخیره شد", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "پین‌کد باید دقیقاً ۴ رقم باشد", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .height(52.dp)
                                .testTag("save_new_pin_button")
                        ) {
                            Text("بروزرسانی رمز", fontSize = 12.sp)
                        }
                    }
                }
            }

            // Section 2: Backup and Restore
            SettingsSectionCard(title = "پشتیبان‌گیری و بازیابی اطلاعات", icon = Icons.Default.Backup) {
                Text(
                    text = "داده‌های مشتریان به صورت کاملاً خصوصی روی دستگاه شما ذخیره می‌شوند. جهت اطمینان از عدم حذف اطلاعات، به صورت دستی نسخه پشتیبان تهیه کنید.",
                    fontSize = 12.sp,
                    color = TextSecondary,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        exportJsonLauncher.launch("webline_customers_backup.json")
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary, contentColor = Color.White),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("export_backup_button")
                ) {
                    Icon(imageVector = Icons.Default.Upload, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("تهیه خروجی فایل پشتیبان (Export)", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedButton(
                    onClick = {
                        importJsonLauncher.launch("application/json")
                    },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = NavyPrimary),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, NavyPrimary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("restore_backup_button")
                ) {
                    Icon(imageVector = Icons.Default.Download, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("بازیابی اطلاعات از فایل پشتیبان (Restore)", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Section 3: App Info & Support Details
            SettingsSectionCard(title = "درباره برنامه و حریم خصوصی", icon = Icons.Default.Info) {
                InfoRowItem(label = "نام اپلیکیشن", value = "مدیریت مشتریهای وبلاین")
                InfoRowItem(label = "نسخه اپلیکیشن", value = "1.0.0 (نسخه پایدار)")
                InfoRowItem(label = "توسعه‌دهنده سیستم", value = "وبلاین / Webline")
                InfoRowItem(label = "ایمیل پشتیبانی فنی", value = "navayearamm@gmail.com")
                
                Divider(color = BorderColor.copy(alpha = 0.5f), modifier = Modifier.padding(vertical = 8.dp))
                
                Text(
                    text = "سیاست حریم خصوصی:",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = NavyPrimary
                )
                Text(
                    text = "این نرم‌افزار به صورت ۱۰۰٪ آفلاین و محلی (Offline-First) فعالیت می‌کند. اطلاعات حساس مشتریان، مبالغ، و فاکتورها منحصراً روی تلفن همراه شما نگهداری شده و هیچ‌گونه پردازش ابری یا انتقال خارجی داده صورت نمی‌گیرد. شما شخصاً مسئول نگهداری از فایل‌های پشتیبان خود در فضای امن (مانند گوگل درایو) هستید.",
                    fontSize = 11.sp,
                    color = TextSecondary,
                    lineHeight = 18.sp
                )
            }

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

@Composable
fun SettingsSectionCard(
    title: String,
    icon: ImageVector,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, BorderColor, RoundedCornerShape(20.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = NavyPrimary)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = NavyPrimary
                )
            }
            Divider(color = BorderColor.copy(alpha = 0.5f), modifier = Modifier.padding(vertical = 12.dp))
            content()
        }
    }
}

@Composable
fun InfoRowItem(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, fontSize = 12.sp, color = TextSecondary)
        Text(text = value, fontSize = 12.sp, color = TextPrimary, fontWeight = FontWeight.Medium)
    }
}
