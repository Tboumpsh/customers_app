package ir.webline.customers.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import ir.webline.customers.data.model.Customer
import ir.webline.customers.data.model.CustomerNote
import ir.webline.customers.data.model.MessageTemplate
import ir.webline.customers.data.model.Task
import ir.webline.customers.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerDetailScreen(
    customer: Customer,
    tasks: List<Task>,
    notes: List<CustomerNote>,
    templates: List<MessageTemplate>,
    onEditCustomer: () -> Unit,
    onDeleteCustomer: () -> Unit,
    onAddTask: (Task) -> Unit,
    onDeleteTask: (Task) -> Unit,
    onToggleTaskStatus: (Task) -> Unit,
    onAddNote: (CustomerNote) -> Unit,
    onDeleteNote: (CustomerNote) -> Unit,
    onGeneratePdf: (String, String) -> Unit,
    onNavigateBack: () -> Unit
) {
    var selectedTab by remember { mutableStateOf(0) }
    val tabTitles = listOf("اطلاعات و مالی", "پیام‌ها و فاکتور", "وظایف و گفت‌وگوها")

    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    // Dialog state for Task Addition
    var showAddTaskDialog by remember { mutableStateOf(false) }
    // Dialog state for Note Addition
    var showAddNoteDialog by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = LightGraySurface,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = customer.name,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = NavyPrimary
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "بازگشت",
                            tint = NavyPrimary
                        )
                    }
                },
                actions = {
                    IconButton(onClick = onEditCustomer, modifier = Modifier.testTag("detail_edit_button")) {
                        Icon(imageVector = Icons.Default.Edit, contentDescription = "ویرایش", tint = NavyPrimary)
                    }
                    IconButton(onClick = onDeleteCustomer, modifier = Modifier.testTag("detail_delete_button")) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = "حذف", tint = StatusRed)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Tabs Bar
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color.White,
                contentColor = NavyPrimary
            ) {
                tabTitles.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = {
                            Text(
                                text = title,
                                fontSize = 12.sp,
                                fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    )
                }
            }

            // Tab Content
            when (selectedTab) {
                0 -> DetailsTab(customer = customer, onGeneratePdf = onGeneratePdf)
                1 -> TemplatesTab(customer = customer, templates = templates, onGeneratePdf = onGeneratePdf)
                2 -> TasksAndNotesTab(
                    customer = customer,
                    tasks = tasks,
                    notes = notes,
                    onAddTaskClick = { showAddTaskDialog = true },
                    onDeleteTask = onDeleteTask,
                    onToggleTaskStatus = onToggleTaskStatus,
                    onAddNoteClick = { showAddNoteDialog = true },
                    onDeleteNote = onDeleteNote
                )
            }
        }
    }

    // Task Addition Dialog
    if (showAddTaskDialog) {
        AddTaskDialog(
            customerId = customer.id,
            onDismiss = { showAddTaskDialog = false },
            onConfirm = { task ->
                onAddTask(task)
                showAddTaskDialog = false
            }
        )
    }

    // Note Addition Dialog
    if (showAddNoteDialog) {
        AddNoteDialog(
            customerId = customer.id,
            onDismiss = { showAddNoteDialog = false },
            onConfirm = { note ->
                onAddNote(note)
                showAddNoteDialog = false
            }
        )
    }
}

// Tab 1: Details & Financial information
@Composable
fun DetailsTab(
    customer: Customer,
    onGeneratePdf: (String, String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(LightGraySurface)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Basic card
        item {
            DetailSectionCard(title = "اطلاعات مشتری", icon = Icons.Default.Person) {
                InfoRow(label = "نام مشتری", value = customer.name)
                InfoRow(label = "نام برند / تجاری", value = customer.brandName.ifEmpty { "ثبت نشده" })
                InfoRow(label = "شماره تلفن", value = customer.phoneNumber.ifEmpty { "ثبت نشده" })
                InfoRow(label = "ایمیل / ارتباط", value = customer.email.ifEmpty { "ثبت نشده" })
                
                if (customer.tags.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "برچسب‌ها:", fontSize = 11.sp, color = TextSecondary, fontWeight = FontWeight.Bold)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        customer.tags.split(",").forEach { tag ->
                            if (tag.trim().isNotEmpty()) {
                                Box(
                                    modifier = Modifier
                                        .background(LightGraySurface, RoundedCornerShape(4.dp))
                                        .border(1.dp, BorderColor, RoundedCornerShape(4.dp))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(text = tag.trim(), fontSize = 10.sp, color = NavyPrimary)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Project card
        item {
            DetailSectionCard(title = "اطلاعات پروژه", icon = Icons.Default.Work) {
                InfoRow(label = "نام پروژه", value = customer.projectName)
                InfoRow(label = "نوع خدمات", value = customer.status)
                InfoRow(label = "شرح پروژه", value = customer.projectDescription.ifEmpty { "توضیحاتی ثبت نشده است." })
                InfoRow(label = "تاریخ شروع", value = customer.startDate.ifEmpty { "ثبت نشده" })
                InfoRow(label = "تاریخ تمدید بعدی", value = customer.nextRenewalDate.ifEmpty { "ثبت نشده" })
            }
        }

        // Financial Card
        item {
            DetailSectionCard(title = "اطلاعات مالی و بانکی", icon = Icons.Default.AccountBalance) {
                InfoRow(
                    label = "مبلغ کل قرارداد / دوره",
                    value = "${"%,.0f".format(customer.amount)} ریال",
                    valueColor = NavyPrimary,
                    isBold = true
                )
                InfoRow(
                    label = "وضعیت پرداخت فاکتور",
                    value = customer.paymentStatus,
                    valueColor = when (customer.paymentStatus) {
                        "پرداخت شده" -> StatusGreen
                        "پرداخت نشده" -> StatusRed
                        "پرداخت ناقص" -> StatusYellow
                        else -> TextSecondary
                    },
                    isBold = true
                )
                InfoRow(label = "شماره شبا (IR)", value = customer.shebaNumber.ifEmpty { "ثبت نشده" })
            }
        }

        // General note card
        if (customer.notes.isNotEmpty()) {
            item {
                DetailSectionCard(title = "توضیحات مهم", icon = Icons.Default.Notes) {
                    Text(
                        text = customer.notes,
                        fontSize = 13.sp,
                        color = TextPrimary,
                        lineHeight = 20.sp
                    )
                }
            }
        }
    }
}

// Tab 2: Message Templates & PDF Invoice
@Composable
fun TemplatesTab(
    customer: Customer,
    templates: List<MessageTemplate>,
    onGeneratePdf: (String, String) -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    var invoiceNoInput by remember { mutableStateOf("1001") }
    var invoiceDescInput by remember { mutableStateOf("") }

    // Replace templates function
    fun formatTemplate(template: String, customer: Customer, invoiceNum: String): String {
        return template
            .replace("{customerName}", customer.name)
            .replace("{projectName}", customer.projectName)
            .replace("{amount}", "%,.0f".format(customer.amount))
            .replace("{renewalDate}", customer.nextRenewalDate.ifEmpty { "منقضی شده" })
            .replace("{invoiceNumber}", invoiceNum)
            .replace("{shebaNumber}", customer.shebaNumber.ifEmpty { "ثبت نشده" })
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(LightGraySurface)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 30.dp)
    ) {
        // Quick PDF Invoice Box
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderColor, RoundedCornerShape(20.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.PictureAsPdf, contentDescription = null, tint = StatusRed)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "صدور فاکتور PDF", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = NavyPrimary)
                    }
                    Divider(color = BorderColor.copy(alpha = 0.5f), modifier = Modifier.padding(vertical = 12.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = invoiceNoInput,
                            onValueChange = { invoiceNoInput = it },
                            placeholder = { Text("مثال: 1001", fontSize = 12.sp) },
                            label = { Text("شماره فاکتور", fontSize = 11.sp) },
                            colors = TextFieldDefaults.colors(focusedIndicatorColor = NavyPrimary, unfocusedIndicatorColor = BorderColor),
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                        )
                        OutlinedTextField(
                            value = invoiceDescInput,
                            onValueChange = { invoiceDescInput = it },
                            placeholder = { Text("مثال: تمدید پشتیبانی وب", fontSize = 12.sp) },
                            label = { Text("توضیحات فاکتور (اختیاری)", fontSize = 11.sp) },
                            colors = TextFieldDefaults.colors(focusedIndicatorColor = NavyPrimary, unfocusedIndicatorColor = BorderColor),
                            modifier = Modifier.weight(1.5f),
                            singleLine = true
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            onGeneratePdf(invoiceNoInput, invoiceDescInput)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary, contentColor = Color.White),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().testTag("generate_pdf_button")
                    ) {
                        Icon(imageVector = Icons.Default.Download, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("ایجاد و ذخیره فایل PDF پیش‌فاکتور", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Section templates Header
        item {
            Text(
                text = "قالب‌های پیام آماده (کپی سریع)",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = NavyPrimary,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        // Loop templates list
        items(templates) { template ->
            val formattedMsg = formatTemplate(template.templateContent, customer, invoiceNoInput)
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderColor, RoundedCornerShape(20.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = template.title,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = NavySecondary
                        )

                        IconButton(
                            onClick = {
                                clipboardManager.setText(AnnotatedString(formattedMsg))
                                Toast.makeText(context, "پیام به کلیپ‌بورد کپی شد", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier
                                .background(Color.White, CircleShape)
                                .size(36.dp)
                                .testTag("copy_template_button_${template.key}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "کپی",
                                tint = NavyPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    Divider(color = BorderColor.copy(alpha = 0.5f), modifier = Modifier.padding(vertical = 10.dp))

                    Text(
                        text = formattedMsg,
                        fontSize = 12.sp,
                        color = TextPrimary,
                        lineHeight = 18.sp,
                        textAlign = TextAlign.Right
                    )
                }
            }
        }
    }
}

// Tab 3: Tasks and call notes
@Composable
fun TasksAndNotesTab(
    customer: Customer,
    tasks: List<Task>,
    notes: List<CustomerNote>,
    onAddTaskClick: () -> Unit,
    onDeleteTask: (Task) -> Unit,
    onToggleTaskStatus: (Task) -> Unit,
    onAddNoteClick: () -> Unit,
    onDeleteNote: (CustomerNote) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(LightGraySurface)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
        contentPadding = PaddingValues(bottom = 30.dp)
    ) {
        // Section: Tasks
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "وظایف و کارها", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = NavyPrimary)
                Button(
                    onClick = onAddTaskClick,
                    colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary, contentColor = Color.White),
                    contentPadding = PaddingValues(horizontal = 12.dp),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.height(36.dp).testTag("add_task_button")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("افزودن کار", fontSize = 12.sp)
                }
            }
        }

        if (tasks.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "هیچ وظیفه‌ای ثبت نشده است.", fontSize = 12.sp, color = TextSecondary)
                }
            }
        } else {
            items(tasks) { task ->
                val isCompleted = task.status == "انجام شده"
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, BorderColor, RoundedCornerShape(20.dp))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Checkbox(
                                checked = isCompleted,
                                onCheckedChange = { onToggleTaskStatus(task) },
                                colors = CheckboxDefaults.colors(checkedColor = StatusGreen)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = task.title,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isCompleted) TextSecondary else TextPrimary
                                )
                                if (task.description.isNotEmpty()) {
                                    Text(text = task.description, fontSize = 11.sp, color = TextSecondary)
                                }
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(top = 4.dp)
                                ) {
                                    Text(text = "تاریخ: ${task.dueDate}", fontSize = 10.sp, color = TextSecondary)
                                    Box(
                                        modifier = Modifier
                                            .background(
                                                when (task.priority) {
                                                    "زیاد" -> StatusRed.copy(alpha = 0.1f)
                                                    "متوسط" -> StatusYellow.copy(alpha = 0.1f)
                                                    else -> NavyPrimary.copy(alpha = 0.1f)
                                                },
                                                RoundedCornerShape(4.dp)
                                            )
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "اولویت: ${task.priority}",
                                            fontSize = 9.sp,
                                            color = when (task.priority) {
                                                "زیاد" -> StatusRed
                                                "متوسط" -> StatusYellow
                                                else -> NavyPrimary
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        IconButton(onClick = { onDeleteTask(task) }) {
                            Icon(imageVector = Icons.Default.Delete, contentDescription = "حذف وظیفه", tint = StatusRed)
                        }
                    }
                }
            }
        }

        // Section: Call/Notes history
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "یادداشت‌های مذاکره و ارتباطات", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = NavyPrimary)
                Button(
                    onClick = onAddNoteClick,
                    colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary, contentColor = Color.White),
                    contentPadding = PaddingValues(horizontal = 12.dp),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.height(36.dp).testTag("add_note_button")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("یادداشت جدید", fontSize = 12.sp)
                }
            }
        }

        if (notes.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "هیچ یادداشتی ثبت نشده است.", fontSize = 12.sp, color = TextSecondary)
                }
            }
        } else {
            items(notes) { note ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, BorderColor, RoundedCornerShape(20.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(text = note.title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                                Text(text = "ثبت شده در: ${note.date}", fontSize = 10.sp, color = TextSecondary)
                            }

                            IconButton(onClick = { onDeleteNote(note) }) {
                                Icon(imageVector = Icons.Default.Delete, contentDescription = "حذف یادداشت", tint = StatusRed)
                            }
                        }

                        Divider(color = BorderColor.copy(alpha = 0.5f), modifier = Modifier.padding(vertical = 8.dp))

                        Text(
                            text = note.description,
                            fontSize = 12.sp,
                            color = TextPrimary,
                            lineHeight = 18.sp,
                            textAlign = TextAlign.Right
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun DetailSectionCard(
    title: String,
    icon: ImageVector,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, BorderColor, RoundedCornerShape(20.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = NavyPrimary)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = NavyPrimary
                )
            }
            Divider(color = BorderColor.copy(alpha = 0.5f), modifier = Modifier.padding(vertical = 12.dp))
            content()
        }
    }
}

@Composable
fun InfoRow(
    label: String,
    value: String,
    valueColor: Color = TextPrimary,
    isBold: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, fontSize = 12.sp, color = TextSecondary, fontWeight = FontWeight.Medium)
        Text(
            text = value,
            fontSize = 13.sp,
            color = valueColor,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal
        )
    }
}

// Add Task Dialog Form
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddTaskDialog(
    customerId: Int,
    onDismiss: () -> Unit,
    onConfirm: (Task) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var dueDate by remember { mutableStateOf("") }
    var priority by remember { mutableStateOf("متوسط") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderColor, RoundedCornerShape(16.dp))
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "تعریف وظیفه جدید برای مشتری",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = NavyPrimary
                )

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("عنوان کار (الزامی)", fontSize = 11.sp) },
                    colors = TextFieldDefaults.colors(focusedIndicatorColor = NavyPrimary, unfocusedIndicatorColor = BorderColor),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    placeholder = { Text("مثال: پیگیری تمدید قرارداد", fontSize = 12.sp) }
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("توضیحات بیشتر (اختیاری)", fontSize = 11.sp) },
                    colors = TextFieldDefaults.colors(focusedIndicatorColor = NavyPrimary, unfocusedIndicatorColor = BorderColor),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    placeholder = { Text("مثال: جزئیات مربوط به نحوه پیگیری", fontSize = 12.sp) }
                )

                OutlinedTextField(
                    value = dueDate,
                    onValueChange = { dueDate = it },
                    label = { Text("تاریخ انجام کار (مثال: 1402/01/15)", fontSize = 11.sp) },
                    colors = TextFieldDefaults.colors(focusedIndicatorColor = NavyPrimary, unfocusedIndicatorColor = BorderColor),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    placeholder = { Text("مثال: 1402/01/15", fontSize = 12.sp) }
                )

                // Priority Select Buttons
                Text(text = "سطح اولویت کار:", fontSize = 11.sp, color = NavyPrimary, fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("کم", "متوسط", "زیاد").forEach { opt ->
                        val selected = priority == opt
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(
                                    if (selected) NavyPrimary else LightGraySurface,
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable { priority = opt }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = opt,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (selected) Color.White else TextPrimary
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    TextButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("انصراف", color = TextSecondary)
                    }
                    Button(
                        onClick = {
                            if (title.trim().isNotEmpty()) {
                                onConfirm(
                                    Task(
                                        customerId = customerId,
                                        title = title.trim(),
                                        description = description.trim(),
                                        dueDate = dueDate.trim(),
                                        status = "انجام نشده",
                                        priority = priority
                                    )
                                )
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("ثبت کار", color = Color.White)
                    }
                }
            }
        }
    }
}

// Add Note Dialog Form
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddNoteDialog(
    customerId: Int,
    onDismiss: () -> Unit,
    onConfirm: (CustomerNote) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var dateString by remember { mutableStateOf("") }

    // Auto prepopulate date with a mock Persian format or placeholder
    LaunchedEffect(Unit) {
        // Simple current Jalali mock or date input help
        dateString = "1405/04/13" // Fallback default or mock date matching prompt timeline
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderColor, RoundedCornerShape(16.dp))
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "ثبت یادداشت جدید گفت‌وگو و مذاکره",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = NavyPrimary
                )

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("عنوان یادداشت گفت‌وگو (الزامی)", fontSize = 11.sp) },
                    colors = TextFieldDefaults.colors(focusedIndicatorColor = NavyPrimary, unfocusedIndicatorColor = BorderColor),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    placeholder = { Text("مثال: توافقات تمدید سالیانه", fontSize = 12.sp) }
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("شرح مذاکرات یا یادداشت ارتباطی", fontSize = 11.sp) },
                    colors = TextFieldDefaults.colors(focusedIndicatorColor = NavyPrimary, unfocusedIndicatorColor = BorderColor),
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("جزئیات مکالمه تلفنی یا چت پیام‌رسان...", fontSize = 12.sp) }
                )

                OutlinedTextField(
                    value = dateString,
                    onValueChange = { dateString = it },
                    label = { Text("تاریخ ثبت یادداشت", fontSize = 11.sp) },
                    colors = TextFieldDefaults.colors(focusedIndicatorColor = NavyPrimary, unfocusedIndicatorColor = BorderColor),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    TextButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("انصراف", color = TextSecondary)
                    }
                    Button(
                        onClick = {
                            if (title.trim().isNotEmpty()) {
                                onConfirm(
                                    CustomerNote(
                                        customerId = customerId,
                                        title = title.trim(),
                                        description = description.trim(),
                                        date = dateString.trim()
                                    )
                                )
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("ثبت یادداشت", color = Color.White)
                    }
                }
            }
        }
    }
}
