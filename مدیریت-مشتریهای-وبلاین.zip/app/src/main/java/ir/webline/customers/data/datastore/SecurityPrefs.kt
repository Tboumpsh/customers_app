package ir.webline.customers.data.datastore

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.security.MessageDigest

val Context.securityDataStore by preferencesDataStore(name = "security_prefs")

class SecurityPrefs(private val context: Context) {

    companion object {
        private val PIN_HASH_KEY = stringPreferencesKey("pin_hash")
        private val IS_PIN_ENABLED_KEY = booleanPreferencesKey("is_pin_enabled")
        private val LAST_ACTIVE_TIMESTAMP_KEY = longPreferencesKey("last_active_timestamp")
    }

    val isPinEnabled: Flow<Boolean> = context.securityDataStore.data.map { prefs ->
        prefs[IS_PIN_ENABLED_KEY] ?: false
    }

    val pinHash: Flow<String?> = context.securityDataStore.data.map { prefs ->
        prefs[PIN_HASH_KEY]
    }

    val lastActiveTimestamp: Flow<Long> = context.securityDataStore.data.map { prefs ->
        prefs[LAST_ACTIVE_TIMESTAMP_KEY] ?: 0L
    }

    suspend fun savePin(pin: String) {
        val hashed = hashString(pin)
        context.securityDataStore.edit { prefs ->
            prefs[PIN_HASH_KEY] = hashed
            prefs[IS_PIN_ENABLED_KEY] = true
        }
    }

    suspend fun disablePin() {
        context.securityDataStore.edit { prefs ->
            prefs[PIN_HASH_KEY] = ""
            prefs[IS_PIN_ENABLED_KEY] = false
        }
    }

    suspend fun verifyPin(pin: String, storedHash: String): Boolean {
        return hashString(pin) == storedHash
    }

    suspend fun updateLastActiveTimestamp(timestamp: Long) {
        context.securityDataStore.edit { prefs ->
            prefs[LAST_ACTIVE_TIMESTAMP_KEY] = timestamp
        }
    }

    private fun hashString(input: String): String {
        return try {
            val md = MessageDigest.getInstance("SHA-256")
            val digest = md.digest(input.toByteArray())
            digest.fold("") { str, it -> str + "%02x".format(it) }
        } catch (e: Exception) {
            input // Fallback to plain in case of failure (should not happen)
        }
    }
}
