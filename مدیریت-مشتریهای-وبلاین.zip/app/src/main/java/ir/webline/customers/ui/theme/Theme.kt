package ir.webline.customers.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val LightColorScheme = lightColorScheme(
    primary = NavyPrimary,
    onPrimary = WhiteBackground,
    primaryContainer = NavySecondary,
    onPrimaryContainer = WhiteBackground,
    secondary = NavySecondary,
    onSecondary = WhiteBackground,
    background = WhiteBackground,
    onBackground = TextPrimary,
    surface = LightGraySurface,
    onSurface = TextPrimary,
    surfaceVariant = LightGraySurface,
    onSurfaceVariant = TextSecondary,
    outline = BorderColor
)

private val DarkColorScheme = darkColorScheme(
    primary = NavyPrimary,
    onPrimary = WhiteBackground,
    primaryContainer = NavySecondary,
    onPrimaryContainer = WhiteBackground,
    secondary = NavySecondary,
    onSecondary = WhiteBackground,
    background = NavyPrimary,
    onBackground = WhiteBackground,
    surface = NavySecondary,
    onSurface = WhiteBackground,
    surfaceVariant = NavySecondary,
    onSurfaceVariant = LightGraySurface,
    outline = BorderColor
)

@Composable
fun WeblineCustomersTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
