package ir.webline.customers.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.webline.customers.ui.theme.NavyPrimary
import ir.webline.customers.ui.theme.NavySecondary
import ir.webline.customers.ui.theme.WhiteBackground

@Composable
fun PinLockScreen(
    isPinEnabled: Boolean,
    onVerifyPin: (String) -> Boolean,
    onSavePin: (String) -> Unit
) {
    var pinText by remember { mutableStateOf("") }
    var confirmPinText by remember { mutableStateOf("") }
    var isConfirmingMode by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }

    val headingText = if (!isPinEnabled) {
        if (isConfirmingMode) "تأیید پین‌کد جدید" else "ایجاد پین‌کد برای اولین ورود"
    } else {
        "لطفاً پین‌کد امنیتی خود را وارد کنید"
    }

    val descriptionText = if (!isPinEnabled) {
        "پین‌کد جهت امنیت اطلاعات حساس مشتریان استفاده می‌شود."
    } else {
        "برای دسترسی به پنل مدیریت وبلاین"
    }

    fun handleDigitInput(digit: String) {
        if (pinText.length < 4) {
            errorMessage = ""
            pinText += digit
            
            if (pinText.length == 4) {
                if (!isPinEnabled) {
                    if (!isConfirmingMode) {
                        // First PIN input done, proceed to confirmation
                        confirmPinText = pinText
                        pinText = ""
                        isConfirmingMode = true
                    } else {
                        // Confirm PIN input done, verify they match
                        if (pinText == confirmPinText) {
                            onSavePin(pinText)
                        } else {
                            errorMessage = "پین‌کدها همخوانی ندارند. دوباره تلاش کنید."
                            pinText = ""
                            isConfirmingMode = false
                        }
                    }
                } else {
                    // Check PIN
                    val correct = onVerifyPin(pinText)
                    if (!correct) {
                        errorMessage = "پین‌کد اشتباه است!"
                        pinText = ""
                    }
                }
            }
        }
    }

    fun handleBackspace() {
        if (pinText.isNotEmpty()) {
            pinText = pinText.substring(0, pinText.length - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NavyPrimary)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Top Icon & Text Header
        Column(
            modifier = Modifier
                .padding(top = 40.dp)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = "قفل",
                tint = Color.White.copy(alpha = 0.9f),
                modifier = Modifier
                    .size(64.dp)
                    .background(Color.White.copy(alpha = 0.1f), CircleShape)
                    .padding(16.dp)
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            Text(
                text = "مدیریت مشتریان وبلاین",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            Text(
                text = headingText,
                color = Color.White.copy(alpha = 0.8f),
                fontSize = 16.sp,
                textAlign = TextAlign.Center
            )
            
            Spacer(modifier = Modifier.height(6.dp))
            
            Text(
                text = descriptionText,
                color = Color.White.copy(alpha = 0.6f),
                fontSize = 13.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Bullet Indicators
            Row(
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                repeat(4) { index ->
                    val isFilled = index < pinText.length
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .padding(4.dp)
                            .clip(CircleShape)
                            .background(if (isFilled) Color.White else Color.White.copy(alpha = 0.25f))
                            .border(1.dp, Color.White.copy(alpha = 0.5f), CircleShape)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            AnimatedVisibility(visible = errorMessage.isNotEmpty()) {
                Text(
                    text = errorMessage,
                    color = MaterialTheme.colorScheme.error,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
            }
        }

        // Custom Numeric Keyboard Pad
        Column(
            modifier = Modifier
                .padding(bottom = 30.dp)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            val keys = listOf(
                listOf("1", "2", "3"),
                listOf("4", "5", "6"),
                listOf("7", "8", "9"),
                listOf("back", "0", "")
            )

            for (row in keys) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    for (key in row) {
                        if (key.isEmpty()) {
                            Spacer(modifier = Modifier.weight(1f))
                        } else if (key == "back") {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .aspectRatio(1.8f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color.White.copy(alpha = 0.1f))
                                    .clickable { handleBackspace() }
                                    .testTag("pin_backspace_button"),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Backspace,
                                    contentDescription = "پاک کردن",
                                    tint = Color.White
                                )
                            }
                        } else {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .aspectRatio(1.8f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color.White.copy(alpha = 0.15f))
                                    .clickable { handleDigitInput(key) }
                                    .testTag("pin_key_$key"),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = key,
                                    color = Color.White,
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
