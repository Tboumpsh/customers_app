package ir.webline.customers.util

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import java.io.OutputStream
import ir.webline.customers.data.model.Customer

object PdfGenerator {

    fun generateInvoicePdf(
        customer: Customer,
        invoiceNumber: String,
        dateString: String,
        description: String,
        outputStream: OutputStream
    ) {
        val pdfDocument = PdfDocument()
        
        // A4 page size in points (595 x 842)
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas

        // Background
        canvas.drawColor(Color.WHITE)

        // Paints
        val borderPaint = Paint().apply {
            color = Color.parseColor("#E2E8F0") // light slate gray
            style = Paint.Style.STROKE
            strokeWidth = 2f
        }

        val primaryColorPaint = Paint().apply {
            color = Color.parseColor("#0C2340") // Navy Primary
            style = Paint.Style.FILL
        }

        val textPrimaryPaint = Paint().apply {
            color = Color.parseColor("#1E293B")
            textSize = 12f
            isAntiAlias = true
            textAlign = Paint.Align.RIGHT
        }

        val textSecondaryPaint = Paint().apply {
            color = Color.parseColor("#64748B")
            textSize = 10f
            isAntiAlias = true
            textAlign = Paint.Align.RIGHT
        }

        val titlePaint = Paint().apply {
            color = Color.parseColor("#0C2340")
            textSize = 20f
            isAntiAlias = true
            isFakeBoldText = true
            textAlign = Paint.Align.RIGHT
        }

        val headerPaint = Paint().apply {
            color = Color.WHITE
            textSize = 12f
            isAntiAlias = true
            isFakeBoldText = true
            textAlign = Paint.Align.RIGHT
        }

        // Draw Outer Border Margin (20pt from edges)
        canvas.drawRect(20f, 20f, 575f, 822f, borderPaint)

        // 1. Header Area
        // Draw Webline Accent Banner on the Right
        canvas.drawRect(20f, 20f, 575f, 100f, primaryColorPaint)

        // Webline Logo/Title Text in Header (Left/Right aligned)
        headerPaint.textAlign = Paint.Align.RIGHT
        canvas.drawText("پیش‌فاکتور وبلاین / Webline Invoice", 550f, 60f, headerPaint)
        
        headerPaint.textAlign = Paint.Align.LEFT
        canvas.drawText("شماره فاکتور: $invoiceNumber", 40f, 60f, headerPaint)

        // 2. Metadata details (Date, etc.)
        canvas.drawText("تاریخ صدور: $dateString", 550f, 130f, textPrimaryPaint)
        canvas.drawText("پشتیبانی فنی و توسعه سیستم‌های نرم‌افزاری وبلاین", 550f, 155f, textSecondaryPaint)

        // Draw line separator
        canvas.drawLine(40f, 180f, 550f, 180f, borderPaint)

        // 3. Customer Info (خریدار)
        canvas.drawText("مشخصات خریدار / مشتری:", 550f, 210f, titlePaint.apply { textSize = 14f })
        canvas.drawText("نام مشتری: ${customer.name}", 550f, 240f, textPrimaryPaint)
        canvas.drawText("نام تجاری / برند: ${customer.brandName.ifEmpty { "ثبت نشده" }}", 550f, 265f, textPrimaryPaint)
        canvas.drawText("شماره تماس: ${customer.phoneNumber.ifEmpty { "ثبت نشده" }}", 550f, 290f, textPrimaryPaint)
        canvas.drawText("پروژه مربوطه: ${customer.projectName}", 550f, 315f, textPrimaryPaint)

        // Draw line separator
        canvas.drawLine(40f, 340f, 550f, 340f, borderPaint)

        // 4. Financial Details Table (جزییات مالی)
        canvas.drawText("جزئیات و مبالغ خدمات:", 550f, 370f, titlePaint.apply { textSize = 14f })
        
        // Draw Table Header Background
        val tableHeaderPaint = Paint().apply {
            color = Color.parseColor("#F1F5F9") // Light Slate Gray fill
            style = Paint.Style.FILL
        }
        canvas.drawRect(40f, 390f, 550f, 420f, tableHeaderPaint)
        canvas.drawRect(40f, 390f, 550f, 420f, borderPaint)

        // Draw Table Headers
        val tableTextPaint = Paint().apply {
            color = Color.parseColor("#1E293B")
            textSize = 10f
            isAntiAlias = true
            isFakeBoldText = true
            textAlign = Paint.Align.RIGHT
        }
        canvas.drawText("شرح خدمات", 530f, 410f, tableTextPaint)
        
        tableTextPaint.textAlign = Paint.Align.LEFT
        canvas.drawText("مبلغ کل (ریال)", 60f, 410f, tableTextPaint)

        // Draw Table Row
        tableTextPaint.textAlign = Paint.Align.RIGHT
        tableTextPaint.isFakeBoldText = false
        val displayDesc = if (description.isNotEmpty()) description else "پشتیبانی و توسعه فنی پروژه ${customer.projectName}"
        canvas.drawText(displayDesc, 530f, 450f, tableTextPaint)

        tableTextPaint.textAlign = Paint.Align.LEFT
        val formattedAmount = "%,.0f".format(customer.amount)
        canvas.drawText(formattedAmount, 60f, 450f, tableTextPaint)

        // Draw lines around rows
        canvas.drawLine(40f, 480f, 550f, 480f, borderPaint)

        // 5. Total and Sheba Info
        canvas.drawText("مبلغ قابل پرداخت:", 550f, 520f, textPrimaryPaint.apply { isFakeBoldText = true })
        textPrimaryPaint.textAlign = Paint.Align.LEFT
        canvas.drawText("$formattedAmount ریال", 60f, 520f, textPrimaryPaint)

        textPrimaryPaint.textAlign = Paint.Align.RIGHT
        textPrimaryPaint.isFakeBoldText = false
        canvas.drawText("وضعیت فاکتور: ${customer.paymentStatus}", 550f, 550f, textPrimaryPaint)

        // Draw Sheba section Box
        val shebaBoxPaint = Paint().apply {
            color = Color.parseColor("#F8FAFC") // lighter gray
            style = Paint.Style.FILL
        }
        canvas.drawRect(40f, 580f, 550f, 650f, shebaBoxPaint)
        canvas.drawRect(40f, 580f, 550f, 650f, borderPaint)

        val shebaTextPaint = Paint().apply {
            color = Color.parseColor("#0C2340")
            textSize = 11f
            isAntiAlias = true
            isFakeBoldText = true
            textAlign = Paint.Align.RIGHT
        }
        canvas.drawText("اطلاعات واریز بانکی:", 530f, 605f, shebaTextPaint)
        shebaTextPaint.isFakeBoldText = false
        shebaTextPaint.color = Color.parseColor("#1E293B")
        val displaySheba = if (customer.shebaNumber.isNotEmpty()) customer.shebaNumber else "شماره شبا ثبت نشده است"
        canvas.drawText("شماره شبا (IR): $displaySheba", 530f, 630f, shebaTextPaint)

        // 6. Footer Area
        val footerPaint = Paint().apply {
            color = Color.parseColor("#64748B")
            textSize = 9f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("این پیش‌فاکتور به صورت خودکار توسط نرم‌افزار مدیریت مشتریان وبلاین صادر گردیده است.", 297.5f, 750f, footerPaint)
        canvas.drawText("وبلاین - ارائه دهنده راهکارهای نوین طراحی سایت، سئو و توسعه دیجیتال مارکتینگ", 297.5f, 770f, footerPaint)

        pdfDocument.finishPage(page)
        
        try {
            pdfDocument.writeTo(outputStream)
        } finally {
            pdfDocument.close()
        }
    }
}
