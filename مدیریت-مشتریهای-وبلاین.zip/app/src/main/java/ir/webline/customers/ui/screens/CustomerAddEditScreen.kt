package ir.webline.customers.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.webline.customers.data.model.Customer
import ir.webline.customers.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerAddEditScreen(
    customerToEdit: Customer?,
    onSaveCustomer: (Customer) -> Unit,
    onNavigateBack: () -> Unit
) {
    // Form fields
    var name by remember { mutableStateOf(customerToEdit?.name ?: "") }
    var brandName by remember { mutableStateOf(customerToEdit?.brandName ?: "") }
    var phoneNumber by remember { mutableStateOf(customerToEdit?.phoneNumber ?: "") }
    var email by remember { mutableStateOf(customerToEdit?.email ?: "") }
    var projectName by remember { mutableStateOf(customerToEdit?.projectName ?: "") }
    var projectDescription by remember { mutableStateOf(customerToEdit?.projectDescription ?: "") }
    var status by remember { mutableStateOf(customerToEdit?.status ?: "طراحی سایت") }
    var paymentStatus by remember { mutableStateOf(customerToEdit?.paymentStatus ?: "پرداخت نشده") }
    var amountText by remember { mutableStateOf(customerToEdit?.amount?.toLong()?.toString() ?: "") }
    var shebaNumber by remember { mutableStateOf(customerToEdit?.shebaNumber ?: "") }
    var startDate by remember { mutableStateOf(customerToEdit?.startDate ?: "") }
    var nextRenewalDate by remember { mutableStateOf(customerToEdit?.nextRenewalDate ?: "") }
    var notes by remember { mutableStateOf(customerToEdit?.notes ?: "") }
    var tags by remember { mutableStateOf(customerToEdit?.tags ?: "") }

    var nameError by remember { mutableStateOf(false) }
    var amountError by remember { mutableStateOf(false) }

    // Dropdowns
    var showStatusDropdown by remember { mutableStateOf(false) }
    var showPaymentDropdown by remember { mutableStateOf(false) }

    val statusOptions = listOf(
        "طراحی سایت",
        "سئو",
        "پشتیبانی فنی",
        "پلن رشد",
        "پرداخت نشده",
        "در انتظار تایید",
        "ادمین محتوایی"
    )

    val paymentOptions = listOf(
        "پرداخت شده",
        "پرداخت نشده",
        "پرداخت ناقص",
        "در انتظار بررسی"
    )

    val scrollState = rememberScrollState()

    fun handleSave() {
        nameError = name.trim().isEmpty()
        val amount = amountText.toDoubleOrNull() ?: 0.0
        amountError = amountText.isNotEmpty() && amountText.toDoubleOrNull() == null

        if (nameError) return

        val finalCustomer = Customer(
            id = customerToEdit?.id ?: 0,
            name = name.trim(),
            brandName = brandName.trim(),
            phoneNumber = phoneNumber.trim(),
            email = email.trim(),
            projectName = projectName.trim(),
            projectDescription = projectDescription.trim(),
            status = status,
            paymentStatus = paymentStatus,
            amount = amount,
            shebaNumber = shebaNumber.trim(),
            startDate = startDate.trim(),
            nextRenewalDate = nextRenewalDate.trim(),
            notes = notes.trim(),
            tags = tags.trim()
        )
        onSaveCustomer(finalCustomer)
    }

    Scaffold(
        containerColor = LightGraySurface,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (customerToEdit == null) "ثبت مشتری جدید" else "ویرایش مشتری",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = NavyPrimary
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "بازگشت",
                            tint = NavyPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Section 1: Customer Profile (مشخصات مشتری)
            SectionCard(title = "مشخصات مشتری") {
                OutlinedFormTextField(
                    label = "نام کامل مشتری (الزامی)",
                    value = name,
                    onValueChange = { name = it; nameError = false },
                    isError = nameError,
                    placeholder = "مثال: علی رضایی",
                    testTag = "input_customer_name"
                )

                OutlinedFormTextField(
                    label = "نام تجاری / برند مشتری",
                    value = brandName,
                    onValueChange = { brandName = it },
                    placeholder = "مثال: شرکت وبلاین"
                )

                OutlinedFormTextField(
                    label = "شماره تلفن تماس",
                    value = phoneNumber,
                    onValueChange = { phoneNumber = it },
                    placeholder = "مثال: 09123456789",
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                )

                OutlinedFormTextField(
                    label = "ایمیل یا لینک ارتباطی",
                    value = email,
                    onValueChange = { email = it },
                    placeholder = "مثال: ali@webline.ir",
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                )
            }

            // Section 2: Project Info (مشخصات پروژه)
            SectionCard(title = "مشخصات پروژه") {
                OutlinedFormTextField(
                    label = "نام پروژه",
                    value = projectName,
                    onValueChange = { projectName = it },
                    placeholder = "مثال: طراحی وب‌سایت فروشگاهی"
                )

                OutlinedFormTextField(
                    label = "توضیحات کلی پروژه",
                    value = projectDescription,
                    onValueChange = { projectDescription = it },
                    placeholder = "توضیحات کوتاه در مورد ویژگی‌ها یا جزئیات پروژه..."
                )

                // Status Dropdown Custom Box
                Text(
                    text = "نوع خدمات / وضعیت پروژه",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = NavyPrimary,
                    modifier = Modifier.padding(top = 4.dp, bottom = 4.dp)
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .background(Color.White, RoundedCornerShape(16.dp))
                        .border(1.dp, BorderColor, RoundedCornerShape(16.dp))
                        .clickable { showStatusDropdown = true }
                        .padding(horizontal = 16.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = status, fontSize = 14.sp, color = TextPrimary)
                        Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null)
                    }

                    DropdownMenu(
                        expanded = showStatusDropdown,
                        onDismissRequest = { showStatusDropdown = false },
                        modifier = Modifier.fillMaxWidth(0.9f)
                    ) {
                        statusOptions.forEach { option ->
                            DropdownMenuItem(
                                text = { Text(option) },
                                onClick = {
                                    status = option
                                    showStatusDropdown = false
                                }
                            )
                        }
                    }
                }
            }

            // Section 3: Financial Info (اطلاعات مالی)
            SectionCard(title = "اطلاعات مالی") {
                OutlinedFormTextField(
                    label = "مبلغ کل قرارداد (ریال)",
                    value = amountText,
                    onValueChange = { amountText = it; amountError = false },
                    isError = amountError,
                    placeholder = "مثال: 150000000",
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    testTag = "input_customer_amount"
                )

                // Payment Status Dropdown
                Text(
                    text = "وضعیت پرداخت فاکتور",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = NavyPrimary,
                    modifier = Modifier.padding(top = 4.dp, bottom = 4.dp)
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .background(Color.White, RoundedCornerShape(16.dp))
                        .border(1.dp, BorderColor, RoundedCornerShape(16.dp))
                        .clickable { showPaymentDropdown = true }
                        .padding(horizontal = 16.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = paymentStatus, fontSize = 14.sp, color = TextPrimary)
                        Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null)
                    }

                    DropdownMenu(
                        expanded = showPaymentDropdown,
                        onDismissRequest = { showPaymentDropdown = false },
                        modifier = Modifier.fillMaxWidth(0.9f)
                    ) {
                        paymentOptions.forEach { option ->
                            DropdownMenuItem(
                                text = { Text(option) },
                                onClick = {
                                    paymentStatus = option
                                    showPaymentDropdown = false
                                }
                            )
                        }
                    }
                }

                OutlinedFormTextField(
                    label = "شماره شبا (IR)",
                    value = shebaNumber,
                    onValueChange = { shebaNumber = it },
                    placeholder = "مثال: 980120000000012345678901"
                )
            }

            // Section 4: Project Timing & Notes (زمان‌بندی و برچسب‌ها)
            SectionCard(title = "زمان‌بندی و برچسب‌ها") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedFormTextField(
                        label = "تاریخ شروع همکاری",
                        value = startDate,
                        onValueChange = { startDate = it },
                        placeholder = "مثال: 1402/01/01",
                        modifier = Modifier.weight(1f)
                    )

                    OutlinedFormTextField(
                        label = "تاریخ تمدید بعدی",
                        value = nextRenewalDate,
                        onValueChange = { nextRenewalDate = it },
                        placeholder = "مثال: 1402/02/01",
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedFormTextField(
                    label = "توضیحات و یادداشت‌های مهم",
                    value = notes,
                    onValueChange = { notes = it },
                    placeholder = "هرگونه یادداشت مهم..."
                )

                OutlinedFormTextField(
                    label = "برچسب‌ها / تگ‌ها (با ویرگول جدا کنید)",
                    value = tags,
                    onValueChange = { tags = it },
                    placeholder = "مثال: طراحی، سئو، فوری"
                )
            }

            // Save Action Button
            Button(
                onClick = ::handleSave,
                colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary, contentColor = Color.White),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("save_customer_button")
            ) {
                Icon(imageVector = Icons.Default.Save, contentDescription = null)
                Spacer(modifier = Modifier.width(12.dp))
                Text(text = "ذخیره تغییرات", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
            
            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}

@Composable
fun SectionCard(
    title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, BorderColor, RoundedCornerShape(20.dp))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = title,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = NavySecondary
            )
            Divider(color = BorderColor.copy(alpha = 0.5f))
            content()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OutlinedFormTextField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    isError: Boolean = false,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    modifier: Modifier = Modifier,
    testTag: String = ""
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text = label,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = if (isError) MaterialTheme.colorScheme.error else NavyPrimary,
            modifier = Modifier.padding(bottom = 4.dp)
        )
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            placeholder = { Text(placeholder, fontSize = 13.sp) },
            isError = isError,
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Color.White,
                unfocusedContainerColor = Color.White,
                focusedIndicatorColor = NavyPrimary,
                unfocusedIndicatorColor = BorderColor
            ),
            shape = RoundedCornerShape(16.dp),
            keyboardOptions = keyboardOptions,
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderColor, RoundedCornerShape(16.dp))
                .testTag(testTag)
        )
    }
}
