package ir.webline.customers.ui.theme

import androidx.compose.ui.graphics.Color

val NavyPrimary = Color(0xFF1A237E)       // Indigo Navy
val NavySecondary = Color(0xFF283593)     // Rich Navy Secondary
val NavyAccent = Color(0xFF304FFE)        // Vibrant Accent Blue

val WhiteBackground = Color(0xFFFFFFFF)   // Clean White
val LightGraySurface = Color(0xFFF8FAFC)  // Soft light gray/slate canvas background
val BorderColor = Color(0xFFE2E8F0)       // Thin slate border color (border-slate-200)

val TextPrimary = Color(0xFF1E293B)       // Dark Slate Text
val TextSecondary = Color(0xFF64748B)     // Cool Gray Subtext
val StatusGreen = Color(0xFF10B981)       // Green for paid/active
val StatusRed = Color(0xFFEF4444)         // Red for unpaid/failed
val StatusYellow = Color(0xFFF59E0B)      // Yellow/Orange for pending/partial
